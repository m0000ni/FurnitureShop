using Microsoft.EntityFrameworkCore;

namespace FurnitureShopNew
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<FurnitureShopDBContext>(options =>
            {
                options.UseSqlServer("Data Source=DESKTOP-D6DTHKQ;Initial Catalog=FurnitureShop;Integrated Security=True;Trust Server Certificate=True");
            });

            var app = builder.Build();
        }
    }
}
