﻿using System.ComponentModel.DataAnnotations;

namespace FurnitureShopNew.Models
{
    public class OrderDetails
    {
        [Key]
        public int order_detail_id { get; set; }

        [Required]
        public int order_id { get; set; }
        public int product_id { get; set; }
        public int quantity { get; set; }
        public decimal unit_price { get; set; }
    }
}