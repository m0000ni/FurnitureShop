﻿using System.ComponentModel.DataAnnotations;

namespace FurnitureShopNew.Models
{
    public class Categories
    {
        [Key]
        public int category_id { get; set; }

        [Required]
        public string name { get; set; }
    }
}
