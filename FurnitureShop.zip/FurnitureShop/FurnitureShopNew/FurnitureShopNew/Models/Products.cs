﻿using Microsoft.Identity.Client;
using System.ComponentModel.DataAnnotations;

namespace FurnitureShopNew.Models
{
    public class Products
    {
        [Key]
        public int product_id { get; set; }

        [Required]
        public string name { get; set; }
        public string description { get; set; }
        public decimal price { get; set; }
        public int category_id { get; set; }
        public int stock_quantity { get; set; }
        public string image_url { get; set; }
    }
}