﻿using System.ComponentModel.DataAnnotations;

namespace FurnitureShopNew.Models
{
    public class Cart
    {
        public ICollection<Products> Products { get; set; } = new List<Products>();

        [Key]
        public int cart_id { get; set; } //primary key 

        [Required]
        public int customer_id { get; set; } //foreign key
                                //can be null :
        public int product_id { get; set; } //foreign key
        public double price_of_products { get; set; }
        public double delivery_price { get; set; }
        public double total_amount { get; set; }
        public int product_quantity_in_cart { get; set; }
    }
}