﻿using System.ComponentModel.DataAnnotations;

namespace FurnitureShopNew.Models
{
    public class Orders
    {
        [Key]
        public int order_id { get; set; }

        [Required]
        public int customer_id { get; set; }
        public DateTime order_date { get; set; }
        public decimal total_amount { get; set; }
    }
}