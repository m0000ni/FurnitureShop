﻿using FurnitureShopNew.Models;
using Microsoft.EntityFrameworkCore;

namespace FurnitureShopNew
{
    public class FurnitureShopDBContext : DbContext
    {
        public FurnitureShopDBContext(DbContextOptions options)
            :base(options) { }

        public DbSet<Cart> Cart { get; set; }
        public DbSet<Categories> Categories { get; set; }
        public DbSet<Customers> Customers { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<Products> Products { get; set; }
    }
}
