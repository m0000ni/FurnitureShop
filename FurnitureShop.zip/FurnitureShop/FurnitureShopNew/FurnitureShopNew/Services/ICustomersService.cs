﻿using FurnitureShopNew.Models;

public interface ICustomersService
{
    Customers FindUserByEmail(string email);
    bool IsLoginInfoValid(string email, string password);
    bool HandleSignUp(string firstName, string lastName, string email, string phone, string address, string password);
    bool HandleUserDelete(string email, string token);
    CustomerDTO GetUserData(string token);
    bool CheckIfUserIsAdmin(string token);
}
