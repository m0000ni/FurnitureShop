﻿using FurnitureShopNew.Models;
using System.Collections.Generic;

public interface IProductsService
{
    Products RemoveProductById(int id);
    void AddProduct(Products product);
    List<Products> GetAllProducts(Products products);
}