﻿using FurnitureShopNew;
using FurnitureShopNew.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

public class ProductsService : IProductsService
{
    public void AddProduct(Products product)
    {
        throw new NotImplementedException();
    }
    Products IProductsService.RemoveProductById(int id)
    {
        throw new NotImplementedException();
    }
    List<Products> IProductsService.GetAllProducts(Products products)
    {
        return ProductsRepo.GetAllProducts()

          handleProductChange(RequestBody(name, description, price, category_id, stock_quantity, image_url))

       {
            Product product = productRepository.getProductByName(name)

            Product updatedProduct = new Product(product, name, description, price, category_id, stock_quantity, image_url)

           productRepository.addProduct(updatedProduct)

       }
        handleProductDeletion(int id)
        {
            productRepository.RemoveProductById(id);
        }
    }
}