﻿using FurnitureShopNew.Models;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;

public class CustomersService : ICustomersService
{
    private readonly ICustomersRepo _userRepository;
    private readonly string _jwtSecret;
    private readonly string _issuer;
    private readonly string _audience;

    public CustomersService(ICustomersRepo userRepository, string jwtSecret, string issuer, string audience)
    {
        _userRepository = userRepository;
        _jwtSecret = jwtSecret;
        _issuer = issuer;
        _audience = audience;
    }

    public Customers FindUserByEmail(string email)
    {
        return _userRepository.FindByEmail(email);
    }

    public bool IsLoginInfoValid(string email, string password)
    {
        Customers user = FindUserByEmail(email);
        return user != null && user.password == password;
    }

    public bool HandleSignUp(string firstName, string lastName, string email, string phone, string address, string password)
    {
        Customers user = new Customers
        {
            first_name = firstName,
            last_name = lastName,
            email = email,
            phone = phone,
            address = address,
            password = password,
            role = "User" 
        };

        _userRepository.AddCustomer(user);
        return true;
    }

    public bool HandleUserDelete(string email, string token)
    {
        throw new NotImplementedException();
    }

    public CustomerDTO GetUserData(string token)
    {
        throw new NotImplementedException();
    }

    public bool CheckIfUserIsAdmin(string token)
    {
        throw new NotImplementedException();
    }

    private string GetEmailFromToken(string token)
    {

        throw new NotImplementedException();
    }

    private CustomerDTO ConvertToCustomerDTO(Customers user)
    {
        throw new NotImplementedException();
    }
}
