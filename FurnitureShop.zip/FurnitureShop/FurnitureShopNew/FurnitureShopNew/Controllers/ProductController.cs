﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;

List<Product> getAllProducts()
{
    return productService.getAllProducts();
}

handleProductChange(RequestBody(product_id, name, description, price, category_id, stock_quantity, image_url))

    {
    productService.handleProductChange(RequestBody(product_id,name, description, price, category_id, stock_quantity, image_url));
}


!!!!!!!!ASK IVAN IF WE SHOULD GET THE ID FROM THE REQUEST BODY OR THE ROUTING - ????
	handleProductDeletion(RequestBody(int id))
	{
	productService.handleProductDeletion(RequestBody(int id))
	}
	
	need to add the logic connected to the Cart
