﻿using FurnitureShopNew.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace FurnitureShopNew.Repositories
{
    public class CustomersRepo : ICustomersRepo
    {
        private readonly FurnitureShopDBContext _context;

        public CustomersRepo(FurnitureShopDBContext context)
        {
            _context = context;
        }

        public void AddCustomer(Customers customer)
        {
            _context.Customers.Add(customer);
            _context.SaveChanges();
        }

        public void DeleteCustomerByEmail(string email)
        {
            Customers customer = _context.Customers.FirstOrDefault(c => c.email == email);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
                _context.SaveChanges();
            }
        }

        public Customers FindByEmail(string email)
        {
            return _context.Customers.FirstOrDefault(c => c.email == email);
        }
    }
}
