﻿using FurnitureShopNew.Models;
using System.Collections.Generic;

public interface IProductsRepo
{
    IEnumerable<Products> GetAllProducts();
    Products GetProductById(int id);
    void AddProduct(Products product);
    void UpdateProduct(Products product);
    void DeleteProduct(Products product);
    List<Products> SearchProductByCategory(int id);
    int GetQuantityById(int id);
}

