﻿using FurnitureShopNew.Models;

public interface ICustomersRepo
{
    void AddCustomer(Customers customer);
    void DeleteCustomerByEmail(string email);
    Customers FindByEmail(string email);
}
