﻿using FurnitureShopNew;
using FurnitureShopNew.Models;
using System.Collections.Generic;
using System.Linq;

public class CategoriesRepo : ICategoriesRepo
{
    private readonly FurnitureShopDBContext _context;

    public CategoriesRepo(FurnitureShopDBContext context)
    {
        _context = context; 
    }

    public IEnumerable<Categories> GetAllCategories()
    {
        return _context.Categories.ToList();
    }

    public Categories GetCategoryById(int id)
    {
        return _context.Categories.Single(c => c.category_id == id); 
    }

    public void AddCategory(Categories category)
    {
        _context.Categories.Add(category);
        _context.SaveChanges();
    }

    public void UpdateCategory(Categories category)
    {
        _context.Categories.Update(category);
        _context.SaveChanges();
    }

    public void DeleteCategory(Categories category)
    {
        _context.Categories.Remove(category);
        _context.SaveChanges();
    }
}