﻿using FurnitureShopNew;
using FurnitureShopNew.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

public class OrdersRepo : IOrdersRepo
{
    private readonly FurnitureShopDBContext _context;
    public OrdersRepo(FurnitureShopDBContext context)
    {
        _context = context;
    }
    public void AddOrders(Orders orders)
    {
        _context.Orders.Add(orders);
        _context.SaveChanges();
    }
    public void DeleteOrders(int ordersId)
    {
        var orderToRemove = _context.Orders.First(o => o.order_id == ordersId);
        _context.Remove(orderToRemove);
        _context.SaveChanges();
    }
    public IEnumerable<Orders> GetAllOrders()
    {
        return _context.Orders.ToList();
    }
    public List<Orders> GetAllOrdersByUser(Customers customer)
    {
        return _context.Orders.Where(o => o.customer_id == customer.customer_id).ToList();
    }
    public Orders GetOrdersById(int ordersId)
    {
        return _context.Orders.Single(c => c.order_id == ordersId);
    }
    public void UpdateOrders(Orders order)
    {
        _context.Orders.Update(order);
        _context.SaveChanges();
    }
}