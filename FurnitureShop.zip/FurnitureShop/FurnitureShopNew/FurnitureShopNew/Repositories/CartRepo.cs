﻿using FurnitureShopNew;
using FurnitureShopNew.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration.EnvironmentVariables;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

public class CartRepo : ICartRepo
{
    private readonly FurnitureShopDBContext _context;
    public CartRepo(FurnitureShopDBContext context)
    {
        _context = context;
    }
    public void AddProductToCart(int cart_Id, int product_Id, int quantity)
    {
        var cart = _context.Cart.Include(c => c.Products).FirstOrDefault(c => c.cart_id == cart_Id);

        if (cart == null)
        {
            throw new ArgumentException("Cart not found");
        }

        var product = _context.Products.FirstOrDefault(p => p.product_id == product_Id);

        if (product == null)
        {
            throw new ArgumentException("Product not found");
        }

        cart.Products.Add(product);
    }
    public decimal GetDeliveryPrice(List<int> productsIds)
    {
        decimal deliveryPrice = 0;
        decimal totalAmount = 0;
        foreach (var productId in productsIds)
        {
            var product = _context.Products.FirstOrDefault(p => p.product_id == productId);
            if (product == null)
            {
                throw new ArgumentException("Product not found!");
            }
            totalAmount += product.price;
        }
        if (totalAmount <= 1000)
        {
            deliveryPrice = 20;
        }
        else
        {
            deliveryPrice = 0;
        }
        return deliveryPrice;
    }

    public decimal GetPriceOfProducts(List<int> productsIds, int cartId)
    {
        decimal price = 0;
        foreach (var productId in productsIds) 
        {
            for (int i = 0; i < productsIds.Count; i++)
            {
                var product = _context.Products.FirstOrDefault(p => p.product_id.Equals(productId));
                if (product == null)
                {
                    throw new ArgumentException("Product not found");
                }
                price += product.price;
            }
        }
        return price;
    }

    public decimal GetTotalPrice(List<int> productsIds)
    {
        decimal priceOfProducts = 0;
        decimal deliveryPrice = 0;
        foreach (var productId in productsIds)
        {
            var cart = _context.Cart.FirstOrDefault(c=>c.product_id==productId);
            if (cart == null)
            {
                throw new ArgumentException("Cart not found");
            }
            priceOfProducts = GetPriceOfProducts(productsIds, cart.cart_id);
            deliveryPrice = GetDeliveryPrice(productsIds);
        }
        decimal totalPrice = priceOfProducts + deliveryPrice;
        return totalPrice;
    }

    private void ResetCartItems(List<int> productsIds)
    {
        foreach (var productId in productsIds)
        {
            var cartItem = _context.Cart.FirstOrDefault(c => c.product_id == productId);
            if (cartItem != null)
            {
                cartItem.product_id = 0; 
                cartItem.price_of_products = 0.0; 
                cartItem.delivery_price = 0.0; 
                cartItem.total_amount = 0.0; 

                _context.Entry(cartItem).State = EntityState.Modified;
            }
        }
        _context.SaveChanges();
    }

    public void MakeOrder(List<int> productsIds)
    {
        decimal totalPrice = 0;
        foreach (var productId in productsIds)
        {
            var cart = _context.Cart.FirstOrDefault(c=>c.product_id==productId);
            if (cart == null)
            {
                throw new ArgumentException("Cart not found!");
            }
            totalPrice = GetTotalPrice(productsIds);
            if (totalPrice <= 0)
            {
                throw new ArgumentException("There in nothing in the cart! Please add products to place an order!");
            }
            var order = new Orders
            {
                order_date = DateTime.Now,
                total_amount = totalPrice,
                customer_id = cart.customer_id
            };

            _context.Orders.Add(order);
            _context.SaveChanges();
            ResetCartItems(productsIds);
        }
    }

    public void RemoveProduct(int cart_Id, int product_Id, int quantity)
    {
        var cartItem = _context.Cart.FirstOrDefault(c => c.cart_id == cart_Id && c.product_id == product_Id);

        if (cartItem == null)
        {
            throw new ArgumentException("Cart item not found");
        }

        // Decrease the product quantity in the cart
        cartItem.product_quantity_in_cart -= quantity;

        // If the quantity is zero or less, remove the cart item
        if (cartItem.product_quantity_in_cart <= 0)
        {
            _context.Cart.Remove(cartItem);
        }

        // Save the changes to the database
        _context.SaveChanges();
    }
}