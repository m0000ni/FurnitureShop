﻿using FurnitureShopNew;
using FurnitureShopNew.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

public class ProductsRepo : IProductsRepo
{
    private readonly FurnitureShopDBContext _context;
    public ProductsRepo(FurnitureShopDBContext context)
    {
        _context = context;
    }
    public void AddProduct(Products product)
    {
        _context.Products.Add(product);
        _context.SaveChanges();
    }
   
    public void DeleteProduct(Products product)
    {
        _context.Products.Remove(product);
        _context.SaveChanges();
    }
    public IEnumerable<Products> GetAllProducts()
    {
        return _context.Products.ToList();
    }
    
    public Products GetProductById(int id)
    {
        return _context.Products.Single(c => c.product_id == id);
    }
    public int GetQuantityById(int id)
    {
        return _context.Products.Count(p => p.product_id == id);
    }
    
    public List<Products> SearchProductByCategory(int id)
    {
        return _context.Products.Where(p => p.category_id == id).ToList();
    }
    public void UpdateProduct(Products product)
    {
        _context.Products.Update(product);
        _context.SaveChanges();
    }
}
