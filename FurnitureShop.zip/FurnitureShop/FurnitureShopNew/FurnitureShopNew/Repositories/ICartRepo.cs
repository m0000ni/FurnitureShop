﻿using FurnitureShopNew.Models;
using System.Collections.Generic;

public interface ICartRepo
{
    void AddProductToCart(int cartId, int productId, int quantity);
    void RemoveProduct(int cartId, int productid,int quantity);
    void MakeOrder(List<int> productsIds);
    decimal GetPriceOfProducts(List<int> productsIds,int cartId);
    decimal GetDeliveryPrice(List<int> productsIds);
    decimal GetTotalPrice(List<int> productsIds);
}