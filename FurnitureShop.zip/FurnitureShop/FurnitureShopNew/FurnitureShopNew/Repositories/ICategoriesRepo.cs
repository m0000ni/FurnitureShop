﻿using FurnitureShopNew.Models;
using System.Collections.Generic;

public interface ICategoriesRepo
{
    IEnumerable<Categories> GetAllCategories();
    Categories GetCategoryById(int id); 
    void AddCategory(Categories category);
    void UpdateCategory(Categories category);
    void DeleteCategory(Categories category);
}